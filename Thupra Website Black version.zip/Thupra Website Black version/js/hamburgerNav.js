	$('#nav-icon').click(function(){
		$(this).toggleClass('open');
	});