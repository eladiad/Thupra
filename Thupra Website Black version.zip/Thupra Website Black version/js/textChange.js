var typed = new Typed('.changeText', {
     strings: ["Web Page.", "Design."],
     typeSpeed: 50,
     loop: true,
     backSpeed: 50,
     startDelay: 750
});