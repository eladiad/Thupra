    $(document).ready(function(){
      $('.main__slider').slick({
        autoplay: true,
       autoplaySpeed: 3100,
       arrows: false,
       mobileFirst: true,
       slidesToScroll: 1,
       swipeToSlide: true,
      });
    });

    $(document).ready(function(){
      $('.about__slider').slick({
        autoplay: true,
       autoplaySpeed: 3100,
       arrows: false,
      });
    });
