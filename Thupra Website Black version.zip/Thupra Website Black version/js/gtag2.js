  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-136590539-2');
  gtag('set', {'user_id': 'ladigo1.'}); // Set the user ID using signed-in user_id.