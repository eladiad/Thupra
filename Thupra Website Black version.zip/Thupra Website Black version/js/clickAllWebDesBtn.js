$(document).ready(function() {
    $("#allWebDes").trigger("click");
    filterSelection('all');
    $('#allWebDes').click();
 });